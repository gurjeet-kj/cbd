﻿<?php include('header.php');if(!isset($_SESSION['user'])){header("Location:signin.php");}
include('leftmenu.php');
?>

<div class="row-fluid">
                    		<!-- Table widget -->
                            <div class="widget  span12 clearfix">
                                <div class="widget-header">
                                    <span><i class="icon-home"></i> Booking History </span>
									
                                </div><!-- End widget-header -->
								
				
				
					<form id="validation_dashboard" action="booking_history.php" method="get" >
				   <div class="section row-fluid  span12 greybackground"><!---- span 12start--->
					<div class="section row-fluid span4">
					<label class="textright">Aircraft</label><div> <select name="fid" id="fid" class="chzn-select" tabindex="4"><option value="">Select Aircraft (Airline)</option>
											<?php $ss=mysql_query("select ID,aircraft,airline_name from cbd_airlines order by ID");
											while($sr=mysql_fetch_array($ss)){
											?><option value="<?php echo $sr['ID'];?>" <?php if(isset($_GET['fid']) && $_GET['fid']==$sr['ID']){ echo "selected='Selected'";}?>><?php echo $sr['airline_name']." - ".$sr['aircraft'];?></option>
											<?php }?></select>
					</div></div>
					
					
					<div class="section row-fluid span4">
					<label class="textright">From Date</label><div><input type="text"  id="birthdays" class=" birthday large" name="start" <?php if(isset($_GET['start'])){ echo 'value="'.$_GET['start'].'"';}else{ echo 'placeholder="Date:  yyyy-mm-dd"';}?>/>

					</div></div>
					
				
					<div class="section row-fluid span4">
										<label class="textright">To Date</label><div><input type="text"  id="birthdaye" class=" birthday large" name="end" <?php if(isset($_GET['end'])){ echo 'value="'.$_GET['end'].'"';}else{ echo 'placeholder="Date:  yyyy-mm-dd"';}?>/>
					</div></div>
					
					
					
					
	<?php /*?><div class="section row-fluid span6 "><label>&nbsp;&nbsp;From & To Date</label><div>
<input type="text"  id="birthdays" class=" birthday small" name="start" <?php if(isset($_GET['start'])){ echo 'value="'.$_GET['start'].'"';}else{ echo 'placeholder="Date:  yyyy-mm-dd"';}?>/>
 <input type="text"  id="birthdaye" class=" birthday small" name="end" <?php if(isset($_GET['end'])){ echo 'value="'.$_GET['end'].'"';}else{ echo 'placeholder="Date:  yyyy-mm-dd"';}?> /><div id="fromtodategreater_empty" class="red"></div><div id="fromtodategreater" class="red"></div> <div id="fromtodategreater_staff" class="red"></div>
	</div></div><?php */?>
	
	<div class="section span12"> <input type="submit" name="submit" value="Search" class="uibutton loading searchbutton"  title="Searching"/></div>
				  </div><!---span12 end--->
				  </form>	
								

                                <div class="widget-content">
                                    
				
				<?php  /* $partial='';$partial1='';$partial2='';////Array ( [fid] => 1 [lang] => 26 [cat] => Administración [gender] => 1 [submit] => Search ) 
						if(isset($_GET['fid']) && ($_GET['fid'])!=''){$fid=$_GET['fid']; $partial.=" and nationality IN (".$fid.")";}else{$fid="";}
						if(isset($_GET['lang']) && ($_GET['lang'])!=''){$lang=$_GET['lang']; $partial.=" and (FIND_IN_SET('".$lang."',com_language)>0 or FIND_IN_SET('".$lang."',commx_language)>0 or FIND_IN_SET('".$lang."',de_language)>0 or FIND_IN_SET('".$lang."',combr_language)>0)";}else{$lang="";}
						if(isset($_GET['cat']) && ($_GET['cat'])!=''){$cat=$_GET['cat']; $partial.=" and (com_category='".$cat."' or commx_category='".$cat."' or de_category='".$cat."' or combr_category='".$cat."')";}else{$cat="";}
						if(isset($_GET['gender']) && ($_GET['gender'])!=''){$gender=$_GET['gender'];$partial.=" and gender='".$gender."'";}else{$gender="";}
						if(isset($_GET['sal']) && ($_GET['sal'])!=''){
						$sal=$_GET['sal'];
						
						 $res_sal = preg_replace("/[^0-9]/", "", $_GET['sal'] );
						
						$partial.=" and ABS(REPLACE(SUBSTRING_INDEX( `salary` , '-', -1 ) ,',',''))>='".$res_sal."'";
						
						
						
						}

						
						if(isset($_GET['cur']) && ($_GET['cur'])!='' && ($_GET['sal'])!=''){
						$cur=$_GET['cur'];
						$partial.=" and currency='".$cur."'";
						}

						if(isset($_GET['salnego']) && ($_GET['salnego'])!=''){$salnego=$_GET['salnego'];$partial.=" and negotiable='1'";}else{$salnego="";}
						
						*/	
				?> 
                                       
									<?php	
				 $where1='';$where2=''; 				
if(isset($_GET['fid']) && $_GET['fid']!=''){
	$where2=" AND cbd_airlines.ID='".$_GET['fid']."'";
}if(isset($_GET['start']) && $_GET['start']!='' && $_GET['end']!=''){
	$where1=" AND DATE(date)>='".$_GET['start']."' AND DATE(date)<='".$_GET['end']."'";
}


$gurjeet_sql="SELECT cbd_flights.flight_number AS FLnumber, airline_name, aircraft, time,cbd_ticket_booking.date,  departure, d_time, arrival, a_time, cbd_class_type.name AS classname, LPAD(price,6,' ') as price, paid<br>
            FROM cbd_flights,  cbd_class_type, cbd_airlines , cbd_ticket_booking<br>
            WHERE (cbd_flights.flight_number = cbd_class_type.flight_number) AND (cbd_ticket_booking.flightno = cbd_class_type.flight_number) AND (classtype = cbd_class_type.name) AND (cbd_flights.airplane_id = cbd_airlines.ID) 
            AND  cbd_ticket_booking.username = '".$_SESSION['user']."' AND paid = '1'".$where1.$where2."<br>
            ORDER BY cbd_ticket_booking.date DESC";


									
										$sql=mysql_query("SELECT cbd_flights.flight_number AS FLnumber, airline_name, aircraft, time,cbd_ticket_booking.date,  departure, d_time, arrival, a_time, cbd_class_type.name AS classname, LPAD(price,6,' ') as price, paid
            FROM cbd_flights,  cbd_class_type, cbd_airlines , cbd_ticket_booking
            WHERE (cbd_flights.flight_number = cbd_class_type.flight_number) AND (cbd_ticket_booking.flightno = cbd_class_type.flight_number) AND (classtype = cbd_class_type.name) AND (cbd_flights.airplane_id = cbd_airlines.ID) 
            AND  cbd_ticket_booking.username = '".$_SESSION['user']."' AND paid = '1'".$where1.$where2."
            ORDER BY cbd_ticket_booking.date DESC");
										
			echo "<table class='table table-bordered table-striped table-hover' id=\"dataTable-\">
          <thead>
          <tr>
		  <th>Airline Aircraft</th>
            <th>Booking Time</th>
            <th>Flight</th>
            
            <th>Date</th>
            <th>Departure</th>
            <th>Departure Time</th>
            <th>Arrival</th>
            <th>Arrival Time</th>
            <th>Class</th>

            <th>Payment($)</th>

            <th>Pay</th>
          </tr>
          </thead>";
		  
    while($row = mysql_fetch_array($sql)) {
        echo "<tbody><tr>";
		 echo "<td>" . $row['airline_name']." ".$row['aircraft']. "</td>";
        echo "<td>" . $row['time'] . "</td>";
        echo "<td>" . $row['FLnumber'] . "</td>";
       
        echo "<td>" . $row['date'] . "</td>";
        echo "<td>" . $row['departure'] . "</td>";
        echo "<td>" . $row['d_time'] . "</td>";
        echo "<td>" . $row['arrival'] . "</td>";
        echo "<td>" . $row['a_time'] . "</td>";
        echo "<td>" . $row['classname'] . "</td>";
        echo "<td align='right'>" . $row['price'] . "</td>";
        if($row['paid'] == 1){
            echo "<td>YES</td>";
        }
       
        echo "</tr>";
    }
    echo " </tbody></table>";

   
   
  
  echo "<div class='sqlbox'><b>SQL QUERY USED:</b> <br>".$gurjeet_sql."</div>";

							
									
										?>
                                </div><!--  end widget-content -->
                            </div><!-- widget  span12 clearfix-->

                    </div>




<div class="row-fluid padding10">
<div class="widget  span12 clearfix padding10">
<?php 
if($where1!='' && $where2!=''){
$sql1=mysql_query("SELECT sum(price) as totalamount
            FROM cbd_flights,  cbd_class_type, cbd_airlines , cbd_ticket_booking
            WHERE (cbd_flights.flight_number = cbd_class_type.flight_number) AND (cbd_ticket_booking.flightno = cbd_class_type.flight_number) AND (classtype = cbd_class_type.name) AND (cbd_flights.airplane_id = cbd_airlines.ID) 
            AND  cbd_ticket_booking.username = '".$_SESSION['user']."' AND paid = '1'".$where1.$where2."
            ORDER BY time");
	$r1=mysql_fetch_array($sql1);		
			$gurjeet2sql= "SELECT sum(price) as totalamount<br>
            FROM cbd_flights,  cbd_class_type, cbd_airlines , cbd_ticket_booking<br>
            WHERE (cbd_flights.flight_number = cbd_class_type.flight_number) AND (cbd_ticket_booking.flightno = cbd_class_type.flight_number) AND (classtype = cbd_class_type.name) AND (cbd_flights.airplane_id = cbd_airlines.ID) 
            AND  cbd_ticket_booking.username = '".$_SESSION['user']."' AND paid = '1'".$where1.$where2."
            ";
			
					 
 echo "<H5>Total Amount Paid Based On Above Search: $ ".$r1['totalamount']."</H5>";
  echo "<div class='sqlbox'><b>SQL QUERY USED:</b> <br>".$gurjeet2sql."</div>";
}
if($where2==''){
$sql2=mysql_query("SELECT sum(price) as totalamount,cbd_airlines.airline_name,cbd_airlines.aircraft
            FROM cbd_flights,  cbd_class_type, cbd_airlines , cbd_ticket_booking
            WHERE (cbd_flights.flight_number = cbd_class_type.flight_number) AND (cbd_ticket_booking.flightno = cbd_class_type.flight_number) AND (classtype = cbd_class_type.name) AND (cbd_flights.airplane_id = cbd_airlines.ID) 
            AND  cbd_ticket_booking.username = '".$_SESSION['user']."' AND paid = '1'".$where1.$where2."
            group by cbd_airlines.ID");
			
			$gurjeet3sql= "SELECT sum(price) as totalamount,cbd_airlines.airline_name,cbd_airlines.aircraft<br>
            FROM cbd_flights,  cbd_class_type, cbd_airlines , cbd_ticket_booking<br>
            WHERE (cbd_flights.flight_number = cbd_class_type.flight_number) AND (cbd_ticket_booking.flightno = cbd_class_type.flight_number) AND (classtype = cbd_class_type.name) AND (cbd_flights.airplane_id = cbd_airlines.ID) 
            AND  cbd_ticket_booking.username = '".$_SESSION['user']."' AND paid = '1'".$where1.$where2."<br>
            GROUP BY cbd_airlines.ID";

 echo "<H5>Total Amount Paid Based On Each Aircraft: </H5>";
 			
while($r2=mysql_fetch_array($sql2)){				 
 echo "<div>Total Amount Paid in <b>".$r2['airline_name']." - ".$r2['aircraft']."</b> : $ ".$r2['totalamount']."</div>";
 
	}
  echo "<div class='sqlbox'><b>SQL QUERY USED:</b> <br>".$gurjeet3sql."</div>";
	
}

/*if($where1==''){
$sql2=mysql_query("SELECT sum(price) as totalamount,cbd_airlines.airline_name,cbd_airlines.aircraft
            FROM cbd_flights,  cbd_class_type, cbd_airlines , cbd_ticket_booking
            WHERE (cbd_flights.flight_number = cbd_class_type.flight_number) AND (cbd_ticket_booking.flightno = cbd_class_type.flight_number) AND (classtype = cbd_class_type.name) AND (cbd_flights.airplane_id = cbd_airlines.ID) 
            AND  cbd_ticket_booking.username = '".$_SESSION['user']."' AND paid = '1'".$where1.$where2."
            group by cbd_airlines.ID");
			
			$gurjeet3sql= "SELECT sum(price) as totalamount,cbd_airlines.airline_name,cbd_airlines.aircraft<br>
            FROM cbd_flights,  cbd_class_type, cbd_airlines , cbd_ticket_booking<br>
            WHERE (cbd_flights.flight_number = cbd_class_type.flight_number) AND (cbd_ticket_booking.flightno = cbd_class_type.flight_number) AND (classtype = cbd_class_type.name) AND (cbd_flights.airplane_id = cbd_airlines.ID) 
            AND  cbd_ticket_booking.username = '".$_SESSION['user']."' AND paid = '1'".$where1.$where2."<br>
            GROUP BY cbd_airlines.ID";

 //echo "<H5>Total amount paid till now: </H5>";
 			
while($r2=mysql_fetch_array($sql2)){				 
 echo "<h5>Total Amount Paid till now in <b>".$r2['airline_name']." - ".$r2['aircraft']."</b> : $ ".$r2['totalamount']."</h5>";
 
	}
  echo "<div class='sqlbox'><b>SQL QUERY USED:</b> <br>".$gurjeet3sql."</div>";
	
}*/

?>

    </div>
  </div>
</div>




</body>
</html>