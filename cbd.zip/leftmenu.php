<!-- left_menu -->
              <div id="left_menu">
                     <ul id="main_menu" class="main_menu">
                                        <li><a href="index.php"><span class="ico gray  dimensions" ></span><b>Search Flights</b></a></li>
<?php if(!isset($_SESSION['user'])){?>
                    <li><a href="#"><span class="ico gray  dimensions" ></span><b>Customer</b></a>
                    <ul><li><a href="signin.php"><span class="ico gray shadow home" ></span><b>Sign In</b></a></li>
                   <li> <a href="signup.php"><span class="ico gray shadow home" ></span><b>Register</b></a></li>
                   <li><a href="booking_history.php"><span class="ico gray  dimensions" ></span><b>Booking History</b></a></li>
                    </ul>
                    </li><?php }else{?>
                    <li><a href="booking_history.php"><span class="ico gray  dimensions" ></span><b>Booking History</b></a></li>
                                       <li><a href="update_profile.php"><span class="ico gray  dimensions" ></span><b>Update Profile</b></a></li>

                    <?php }?>
                    
					<!--<li><a href="#"><span class="ico gray  dimensions" ></span><b>Jobs</b></a>
                        <ul><li><a href="add_job.php"><span class="ico gray shadow home" ></span><b>Add Job</b></a></li>
                          <li><a href="dashboard.php"><span class="ico gray shadow home" ></span><b>Active Jobs</b></a></li>
					     <li><a href="deactivated_jobs.php"><span class="ico gray  dimensions" ></span><b>Deactivated Jobs</b></a></li>
 						<li><a href="#"><span class="ico gray  dimensions" ></span><b>Publications Later</b></a></li>					
                        </ul>
                     </li>-->
						
						 
						<?php /*?> <li>
                          <?php
						$sqlremember=mysql_query("SELECT count(id) as countrem FROM `addapplicant_remember` WHERE DATE(created_date)<=DATE(NOW())");$rremember=mysql_fetch_array($sqlremember);if($rremember['countrem']>0){?><img src="images/bulb.png" alt="Idea" style="float:right;padding:9px;"/><div class="notification rem" ><?php echo $rremember['countrem'];?></div><?php }
						 ?>
                         <a href="candidates.php"><span class="ico gray  dimensions" ></span><b>Candidates</b></a>
						 <ul>
						  <li><a href="add_applicant_manual.php"><span class="ico gray shadow home" ></span><b>Manual Applicant Add</b></a></li>
						 <li><?php if($rremember['countrem']>0){?><img src="images/bulb.png" alt="Idea" style="float:right;padding:9px;"/><div class="notification rem" ><?php echo $rremember['countrem'];?></div><?php }
						 ?><a href="reminder_headhunting.php"><span class="ico gray shadow home" ></span><b>Reminders Headhunting</b></a></li>
						 <li><a href="search_applicant.php"><span class="ico gray shadow home" ></span><b>Search All Profiles</b></a></li>
						 </ul>
						 </li><?php */?>
						 
						<?php /*?> <li><a href="#"><span class="ico gray  dimensions" ></span><b>News<?php
						
						 $sql_news_notification=mysql_query("select * from news a where (FIND_IN_SET('".$_SESSION["staff"]."', news_access) > 0 or FIND_IN_SET('".$_SESSION["admin_id"]."', news_access_to_employee)>0) and news_created_by<>'".$_SESSION["admin_name"]."' and NOT EXISTS(Select * FROM news_user as b WHERE a.id =b.news_id and b.user_id='".$_SESSION["admin_id"]."') and news_created_date>='".$jodate_l."' and news_created_by!='".$_SESSION["admin_name"]."'");
						
						$sql_news_notification_count=mysql_num_rows($sql_news_notification);
						if($sql_news_notification_count>0){echo "<img src=\"images/icon/color_18/mail.png\">";}					
					  ?></b></a><ul><li><a href="news.php"><span class="ico gray  dimensions" ></span><b>Send/Sent News</b></a></li>
					  <li><a href="news_all.php"><span class="ico gray  dimensions" ></span><b>News Received</b></a></li></ul>
					  
					 </li><?php */?>
						 
						 
						 
					  <!-- <li><a href="#"><span class="ico gray  dimensions" ></span><b>Clients & Agents</b></a>
                       <ul><li><a href="clients.php"><span class="ico gray  dimensions" ></span><b>Clients</b></a></li>
                       		<li><a href="agent.php"><span class="ico gray  dimensions" ></span><b>Agents</b></a></li>
                       </ul>

                       
                       </li>-->
					 
					   
					   
					  
					 
					  
					  
    </ul>
               </div>
              
              <div id="content" >
                <div class="inner">
  				<div class="row-fluid">
                          <div class="span12 clearfix">
                              <?php /*?><div class="logo"><p align="center" style="font-size:45px"><img src="images/logo.png" width="250"/></p>
                              <ul id="shortcut" class="clearfix">
                           <!--         <li> <a href="#" title="Setting" > <img src="images/icon/shortcut/setting.png" alt="setting" /><strong>Setting</strong></a> </li> 
                           -->
                              </ul></div><?php */?>
                          </div>
                  </div>
 <?php
	  	
			/////////////////
			if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 600) && $_SESSION['staff']!=4) {
			echo "<script>alert('Not to forget to start the time tracker');</script>";
				unset($_SESSION['LAST_ACTIVITY']);     // unset $_SESSION variable for the run-time 
			}
			//echo "<br><br><br><br><br><br>####";print_r($_SESSION); echo time();
			////////////////
			
			
	  
	  ?> 