﻿<?php include('header.php');
include('leftmenu.php');


if(!isset($_SESSION['user'])){
    header("Location: signin.php");
}else{
    $user = $_SESSION['user'];	

$ticket_number=date('Hisdmy');
 $sql = mysql_query("UPDATE cbd_ticket_booking
            SET paid = '1', ticket_number=".$ticket_number."
            WHERE username = '$user' AND paid = '0'");



$sql = "SELECT ticket_number,FL.flight_number AS FLnumber, airline_name, aircraft, B.ID AS bookid, time, B.date,  departure, d_time, arrival, a_time, C.name AS classname, seats, price
            FROM cbd_flights FL,  cbd_class_type C, cbd_airlines AP , cbd_ticket_booking B
            WHERE (FL.flight_number = C.flight_number) AND (B.flightno = C.flight_number) AND (classtype = C.name) AND (FL.airplane_id = AP.ID) 
            AND  B.username = '$user' AND paid = '1' AND ticket_number='".$ticket_number."'
            ORDER BY time";

//echo $sql;

$gurjeetsql="SELECT ticket_number,FL.flight_number AS FLnumber, airline_name, aircraft, B.ID AS bookid, time, B.date,  departure, d_time, arrival, a_time, C.name AS classname, seats, price
            FROM cbd_flights FL,  cbd_class_type C, cbd_airlines AP , cbd_ticket_booking B
            WHERE (FL.flight_number = C.flight_number) AND (B.flightno = C.flight_number) AND (classtype = C.name) AND (FL.airplane_id = AP.ID) 
            AND  B.username = '$user' AND paid = '1' AND ticket_number='".$ticket_number."'";
			
$result = mysql_query($sql);
$rowcount = mysql_num_rows($result);
?>
<div class="row-fluid">
<div class="widget  span12 clearfix">
<div class="widget-header"><span><i class="icon-home"></i>Selected Flights Added In Cart</span></div>
   <div class="widget-content">
   <?php
   /* if($rowcount == 0){
        echo "<div class='alert alert-info'><strong>No flight in the cart!</strong></div>";
    }
    else{
    echo "<div class='alert alert-info'>Following flights in your cart:</div>";
*/

echo "<h2>Your flight has been booked sucessfully!</h2>";
    echo "<table class='table table-bordered table-striped table-hover' style='width:60%;margin:auto;'>";
         
          
    while($row = mysql_fetch_array($result)) {
       
        echo "<tr><td>Ticket Number</td><td>" . $row['ticket_number'] . "</td></tr>";
        echo "<tr><td>Flight Number</td><td>" . $row['FLnumber'] . "</td></tr>";
        echo "<tr><td>Aircraft</td><td>" . $row['airline_name']." - ".$row['aircraft']. "</td></tr>";
        echo "<tr><td>Date</td><td>" . $row['date'] . "</td></tr>";
        echo "<tr><td>Departure From</td><td>" . $row['departure'] . "</td></tr>";
        echo "<tr><td>Departure Time</td><td>" . $row['d_time'] . "</td></tr>";
        echo "<tr><td>Arrival From</td><td>" . $row['arrival'] . "</td></tr>";
        echo "<tr><td>Arrival Time</td><td>" . $row['a_time'] . "</td></tr>";
        echo "<tr><td>Flight Class</td><td>" . $row['classname'] . "</td></tr>";

       
        


       
    }
    echo "</table>";
	
	
	  echo "<div class='sqlbox'><b>SQL QUERY USED:</b> <br>".$gurjeetsql."</div>";

	
	}?></div><!--  end widget-content -->
</div><!-- widget  span12 clearfix-->
</div><!--row-fluid-->

	
    	 
				 
            
				
  </body>
        </html>