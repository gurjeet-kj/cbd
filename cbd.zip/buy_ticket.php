<?php include('header.php');
include('leftmenu.php');


if(!isset($_SESSION['user'])){
    header("Location: customersignin.html");
}else{
    $user = $_SESSION['user'];	


$sql = "SELECT FL.flight_number AS FLnumber, airline_name, aircraft, B.ID AS bookid, time, B.date,  departure, d_time, arrival, a_time, C.name AS classname, seats, price
            FROM cbd_flights FL,  cbd_class_type C, cbd_airlines AP , cbd_ticket_booking B
            WHERE (FL.flight_number = C.flight_number) AND (B.flightno = C.flight_number) AND (classtype = C.name) AND (FL.airplane_id = AP.ID) 
            AND  B.username = '$user' AND paid = '0'
            ORDER BY time";

//echo $sql;
$result = mysql_query($sql);
$rowcount = mysql_num_rows($result);
?>
<div class="row-fluid">
<div class="widget  span12 clearfix">
<div class="widget-header"><span><i class="icon-home"></i>Selected Flights Added In Cart</span></div>
   <div class="widget-content">
   <?php
    if($rowcount == 0){
        echo "<div class='alert alert-info'><strong>No flight in the cart!</strong></div>";
    }
    else{
    echo "<div class='alert alert-info'>Following flights in your cart:</div>";



    echo "<table class='table table-bordered table-striped table-hover' id='dataTable'>
          <thead>
          <tr>
            <th>Time</th>
            <th>Flight</th>
            <th>Aircraft</th>
            <th>Date</th>
            <th>Departure</th>
            <th>Departure Time</th>
            <th>Arrival</th>
            <th>Arrival Time</th>
            <th>Class</th>

            <th>Price</th>

            <th>Pay</th>
          </tr>
          </thead>";
    while($row = mysql_fetch_array($result)) {
        echo "<tbody><tr>";
        echo "<td>" . $row['time'] . "</td>";
        echo "<td>" . $row['FLnumber'] . "</td>";
        echo "<td>" . $row['airline_name']." ".$row['aircraft']. "</td>";
        echo "<td>" . $row['date'] . "</td>";
        echo "<td>" . $row['departure'] . "</td>";
        echo "<td>" . $row['d_time'] . "</td>";
        echo "<td>" . $row['arrival'] . "</td>";
        echo "<td>" . $row['a_time'] . "</td>";
        echo "<td>" . $row['classname'] . "</td>";

        echo "<td>" . $row['price'] . "</td>";
        
       
            //calculate number of remain seats
            $seatreserved = "SELECT flightno, classtype, COUNT(*)
                        FROM cbd_ticket_booking B
                        WHERE B.date = '".$row['date']."' AND B.flightno = '".$row['FLnumber']."'AND B.classtype ='".$row['classname']."' AND paid=1
                        GROUP BY flightno, classtype";
            $reserved = mysql_query($seatreserved);   
            $reservedNumber = mysql_fetch_array($reserved);
            
            $seats = mysql_query("SELECT seats FROM cbd_class_type C WHERE C.flight_number='".$row['FLnumber']."' AND C.name= '".$row['classname']."'");
            $seatsNumber = mysql_fetch_array($seats);


            if(mysql_num_rows($reserved)>0){            
                $availableNumber = $seatsNumber['seats'] - $reservedNumber['COUNT(*)'];
            }else{
                $availableNumber = $seatsNumber['seats'];
            }
        
     
        
        if($availableNumber>0){
        echo '<td>
            <form action="cartdelete.php" method="post">
            <input type="hidden" name="bookid" value="'.$row['bookid'].'" >
            <button type="submit" class="btn btn-danger">Delete</button></div>
            </form>        
            </td>';
        }else{
            echo "<td><button type='button' class='btn btn-warning' onclick='myFunction()'>No seat Available now</button></td>";
        }
        
		$sum = mysql_query("SELECT SUM(price)
							            FROM cbd_ticket_booking B, cbd_class_type C
							            WHERE B.username = '$user' AND paid = '0'
							            AND classtype=C.name AND flightno = C.flight_number");

		$t = mysql_fetch_array($sum);
		$total = $t['SUM(price)'];



        echo "</tr>";
    }
    echo " </tbody></table>";
?></div><!--  end widget-content -->
</div><!-- widget  span12 clearfix-->
</div><!--row-fluid-->
<?php
	
    echo " <form action='thank_you.php' method='post'>";
    echo "<div class='row-fluid'>
			  <div class='section row-fluid span4'></div>
			  <div class='section row-fluid span4'><p class='lead'>Total Amount: <span id='total'>$".$total."</span></p></div>
			  <div class='section row-fluid span4'><button type='submit' class='uibutton loading'>Pay Now</button></div>
			</div>";
    
    echo "</form>";
    echo "<br>";

    }











}

?> 

<!--<script type="text/javascript">
			jQuery(document).ready(function() { $("#perweek").hide();
				 $("#radio-1").live('click',function(){$("#perweek").show();});
				 $("#radio-2").live('click',function(){$("#perweek").hide();});
			});
</script>-->
              
				
 				 <!-------------------table start-------------->
<script>$(document).ready(function() {
	 var oTable = $('#dataTable').dataTable();
		 oTable.fnSort( [ [0,'desc'], [1,'asc'] ] ); // Sort immediately with columns 0 and 1
	 });
		jQuery(document).ready(function() { 
			 $(".showendtime").hide();
			 $(".showendtimebt").live('click',function(){
			 $("#showendtime-"+this.id).show();});
			 
				 $('.sendform').click(function(){ 
					 var buttonid=this.id;
					 var myarr = buttonid.split("-");
					 var taskentryid=myarr[1];
					 var endtime = $('#timepicker'+taskentryid).val();
					 var enddate = $('#birthday'+taskentryid).val();
					
					  //---ajax start---
					  $.ajax({
							  url: "ajax/start_work_mannual_endtime.php",
							  data: {'endtime': endtime,'enddate':enddate,'taskentryid':taskentryid},
							  success: function(data){	
								  if(data==''){ $('#msg_enddatetime'+taskentryid).html('Please try after sometime!').show();
								  }
								  else if(data==0){ $('#msg_enddatetime'+taskentryid).html('Please enter date & time!').show();
								  }else{
								  $('#msg_enddatetime'+taskentryid).html('').hide();
									   $('#showactiveenddatetime'+taskentryid).html(data).show();  $('#'+taskentryid).hide(); $('#showendtime-'+taskentryid).hide();
								  }
							  },
						 });
					  //---ajax end---- 
				 });
		});
</script>
<?php 


?>

                   
				 
				 
            
				 
  </body>
        </html>
