<?php include('header.php');
include('leftmenu.php');
if($_POST){

$username = $_POST['username'];
 $firstname =$_POST['firstname'];
  $lastname =$_POST['lastname'];
   $tel =$_POST['tel'];
 $email = $_POST['email'];
 $pwd1 = $_POST['pwd1'];

 if(isset($_POST['middlename'])){
 	$middlename = $_POST['middlename'];
 }else{
 	$middlename = "";
 }

  if(isset($_POST['gender'])){
 	$gender = $_POST['gender'];
 }else{
 	$gender = "";
 }

  if(isset($_POST['birthday'])){
 	$birthday = $_POST['birthday'];
 }else{
 	$birthday = "";
 }


$update_query=mysql_query("UPDATE cbd_passengers set firstname='$firstname',middlename='$middlename',lastname='$lastname',email='$email',phone='$tel',gender='$gender',birthday='$birthday',passport_number='".$_POST['passport_number']."',passport_issue='".$_POST['passport_issue']."',passport_expiry='".$_POST['passport_expiry']."',country_of_origin='".$_POST['country_of_origin']."',password='$pwd1' where username='".$_SESSION['user']."'");


 
$gurjeet_sql="UPDATE cbd_passengers <br>set firstname='$firstname', middlename='$middlename', lastname='$lastname', email='$email', phone='$tel', gender='$gender', birthday='$birthday', passport_number='".$_POST['passport_number']."', passport_issue='".$_POST['passport_issue']."', passport_expiry='".$_POST['passport_expiry']."', country_of_origin='".$_POST['country_of_origin']."', password='$pwd1'<br> where username='".$_SESSION['user']."'";

echo "<h2>You have sucessfully updated your profile details!</h2>";
echo "<div class='sqlbox'><b>SQL QUERY USED:</b> <br>".$gurjeet_sql."</div>";

        
}

$sql=mysql_query("select * from cbd_passengers where username='".$_SESSION['user']."'");
$r=mysql_fetch_array($sql);
?>  

                <!-------------------table-------------->
                    <div class="row-fluid">
                    
                    		<!-- Widget -->
                            <div class="widget  span12 clearfix">
                            
                                <div class="widget-header">
                                    <span><i class="icon-bookmark"></i>Update Profile Details</span> 
                                </div><!-- End widget-header -->	
                                
                                <div class="widget-content">    
        
                                <form id="validation_demo" action="update_profile.php" method="post"> 
                                <div class="row-fluid">
                                    
        
                                 <div class="span12"><div class="section "><label>First Name<small></small></label>   
                                     <div><input type="text" class="large" name="firstname" id="firstname" placeholder="First Name*" value="<?php echo $r['firstname'];?>"></div> </span></div>
								</div> 
                                
                                <div class="span12"><div class="section "><label>Middle Name<small></small></label>   
                                     <div><input value="<?php echo $r['middlename'];?>" type="text" class="large" name="middlename" id="middlename" placeholder="Middle Name"></div> <span id="admin_nameexist" class="green"></span></div>
								</div> 
                                
                                <div class="span12"><div class="section "><label>Last Name<small></small></label>   
                                     <div><input value="<?php echo $r['lastname'];?>" type="text" class="large" name="lastname" id="lastname" placeholder="Last Name*"></div> <span id="admin_nameexist" class="green"></span></div>
								</div> 
                                
                                
                                
                                
                                
                                
                               <div class="span12"><div class="section "><label>Email<small></small></label>   
                              <div><input value="<?php echo $r['email'];?>" type="text" class="large" name="email" id="email" placeholder="Email*"></div></div>
								</div>
                                
                                
                             <div class="span12"><div class="section "><label>Date Of Birth<small></small></label>   
                                     <div><input value="<?php echo $r['birthday'];?>" type="text" class="large" name="birthday" id="birthday" placeholder="Date Of Birth"></div> <span id="admin_nameexist" class="green"></span></div>
								</div> 
                                
                                <div class="span12"><div class="section "><label>Phone Number<small></small></label>   
                                     <div><input value="<?php echo $r['phone'];?>" type="text" class="large" name="tel" id="tel" placeholder="Phone Number"></div> <span id="admin_nameexist" class="green"></span></div>
								</div> 
                                
                                
                                <div class="span12"><div class="section "><label>Passport Number<small></small></label>   
                                     <div><input value="<?php echo $r['passport_number'];?>" type="text" class="large" name="passport_number" id="passport_number" placeholder="Passport Number"></div> <span id="admin_nameexist" class="green"></span></div>
								</div> 
                                
                                <div class="span12"><div class="section "><label>Passport Issue Date<small></small></label>   
                                     <div><input value="<?php echo $r['passport_issue'];?>" type="text" class="large" name="passport_issue" id="passport_issue" placeholder="Passport Issue Date: dd/mm/yyyy"></div> <span id="admin_nameexist" class="green"></span></div>
								</div> 
                                
                              <div class="span12"><div class="section "><label>Passport Expiry Date<small></small></label>   
                                     <div><input value="<?php echo $r['passport_expiry'];?>" type="text" class="large" name="passport_expiry" id="passport_expiry" placeholder="Passport Expiry Date: dd/mm/yyyy"></div> <span id="admin_nameexist" class="green"></span></div>
								</div> 
                                  
                                <div class="span12"><div class="section "><label>Country Of origin<small></small></label>   
                                     <div><input value="<?php echo $r['country_of_origin'];?>" type="text" class="large" name="country_of_origin" id="country_of_origin" placeholder="Country"></div> <span id="admin_nameexist" class="green"></span></div>
								</div> 
                                <div class="span12"><div class="section ">
                                                    <label>Gender<small></small></label>   
                                                    <div> 
                                                      <div>
                                 <label for="radio-2" >Male</label><input type="radio" name="gender" id="radio-2" value="Male"  class="ck" <?php if($r['gender']=='Male'){echo "Checked";}?> />
                                 <label for="radio-1" >Female</label><input type="radio" name="gender" id="radio-1" value="Female"  class="ck"  <?php if($r['gender']=='Female'){echo "Checked";}?> />
                                                      </div>
                                                    </div>
                                            </div></div>
								
								<div class="span12">			
                                            <div class="section">
                                                        <label> Login Details  <small></small></label>
                                                    <div>
                                            <input type="text"  placeholder="Username*" name="username" id="username"  class=" medium" readonly />
                                                        <span class="f_help"> Username login should be between 3 and not more than 20 characters.</span> 
                                                    </div>
                                                    <div>
                                              <input value="<?php echo $r['password'];?>" type="password" placeholder="Password*" class="validate[required,minSize[3]] medium"  name="pwd1" id="pwd1"  />														<span class="f_help"> Password should be atleast 3 characters.</span> 
                                                    </div>
                                            </div>
											
											
											
                                           
                                            
                                            
                                            
                                           
                                            
                                            
                                            
											</div>
											
                                           
                                            
   
											<!-----end------>
											
											<div class="span12">
                                            <div class="section last">
                                                    <div>
                                                    <input type="submit" name="submit" value="Update" class="uibutton loading" title="Updating" />  
                                                    </div>
                                           </div>
                                    </div>
        
                                    </div><!-- row-fluid -->
                                    </form>
                                </div><!--  end widget-content -->
                            </div><!-- widget  span12 clearfix-->

                    </div>
                 <!-----------------table------------------->

                </div> <!--// End inner -->
                <span class="tip"><a  href="https://latinamericarecruitment.com" title="" >LATAM Management Recruitment</a> </span></div>
              </div> <!--// End ID content -->

  </body>
        </html>
