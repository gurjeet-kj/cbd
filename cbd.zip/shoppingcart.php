﻿<?php
include('config/config.php');

$type = $_POST["type"];
//date_default_timezone_set("America/Chicago");
$t=time();
$time = date("Y-m-d h:i:s");


if(!isset($_SESSION['user'])){
    header("Location: signin.php");
}else{
    $user = $_SESSION['user'];


	if($type =="all" || $type =="onewaynonstop" ){

	$flightno = $_POST["flightno"];
	$class = $_POST["classtype"];
	$price = $_POST["price"];
	$date = $_POST["date"];

	$sql = "INSERT INTO cbd_ticket_booking (time, date, flightno, username, classtype, paid) 
			VALUES ('$time', '$date', '$flightno', '$user', '$class', '0')";;


	$result = mysql_query($sql);
    header("Location: buy_ticket.php");
	}

	if($type =="oneway1stop"){

	$flightno = $_POST["flightno"];
	$class = $_POST["classtype"];
	$price = $_POST["price"];
	$date = $_POST["date"];


	$flightno2 = $_POST["flightno2"];
	$class2 = $_POST["classtype2"];
	$price2 = $_POST["price2"];


	$sql = "INSERT INTO cbd_ticket_booking (time, date, flightno, username, classtype, paid) 
			VALUES ('$time', '$date', '$flightno', '$user', '$class', '0')";;

	$result = mysql_query($sql);

	$sql2 = "INSERT INTO cbd_ticket_booking (time, date, flightno, username, classtype, paid) 
			VALUES ('$time', '$date', '$flightno2', '$user', '$class2', '0')";;

	$result2 = mysql_query($sql2);
    header("Location: buy_ticket.php");
//echo $sql."__".$sql2;
	}

	
	if($type =="roundtrip"){

	$flightno = $_POST["flightno"];
	$class = $_POST["classtype"];
	$price = $_POST["price"];
	$date = $_POST["date"];


	$flightno2 = $_POST["flightno2"];
	$class2 = $_POST["classtype2"];
	$price2 = $_POST["price2"];

	$returndate = $_POST["date2"];

	$sql = "INSERT INTO cbd_ticket_booking (time, date, flightno, username, classtype, paid) 
			VALUES ('$time', '$date', '$flightno', '$user', '$class', '0')";;

	$result = mysql_query($sql);

	$sql2 = "INSERT INTO cbd_ticket_booking (time, date, flightno, username, classtype, paid) 
			VALUES ('$time', '$returndate', '$flightno2', '$user', '$class2', '0')";;

	$result2 = mysql_query($sql2);

    header("Location: buy_ticket.php");
	}


    echo "Error adding to cart..";










}



?>



