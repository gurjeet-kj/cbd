<?php include('header.php');
include('leftmenu.php');
?>

<script type="text/javascript">
	$(document).ready(function(){
		
		$("#oneway").show();
	$("#roundtrip").hide();
	$("#all").hide();
	
	$("#button1").click(function(){		
		$("#oneway").show();
		$("#roundtrip").hide();
		$("#all").hide();
	});
	$("#button2").click(function(){
		$("#roundtrip").show();
		$("#oneway").hide();
		$("#all").hide();
	});
	$("#button3").click(function(){
		$("#oneway").hide();
		$("#roundtrip").hide();
		$("#all").show();
	}); 
	 

	 		  	
	});//document ready end
</script>


<!----Start CBD Search---->
 <div class="row-fluid">
                    		<!-- Table widget -->
                            <div class="widget  span12 clearfix">
                                <div class="widget-header">
                                    <span><i class="icon-home"></i> Search Flights </span>
                                </div><!-- End widget-header -->
								
				
<style>.top30px{padding:30px;}.greybackground{ padding:20px}.sqlbox{

    background: #1c9ee9;
    padding: 10px;
    font-size: 14px;
    color: #fff;
    width: 90%;
    margin: 20px auto;
    border: 2px solid #0d5d8b;
    box-shadow:2px 2px 7px inset #fff;line-height:1.9;}
    #dataTable_wrapper .row-fluid.tb-head{ display:none;}
    </style>				

		
        
        <div class="section row-fluid  span12 top30px"><!---- span 12start--->
        
        <div class="section row-fluid span3"><label>Search Your Flights Here:</label></div>
					<div class="section row-fluid span3">
                    <div class="btn-group">
                    <label for="button1"><input type="radio"  id="button1" name="flightsearch"  checked="checked"/> One Way</label>
			<!--<button id="button1" type="button" href="#oneway" class="btn btn-primary">One-way</button>-->
			</div>
					</div>
                    <div class="section row-fluid span3"><div class="btn-group"><label for="button2"><input name="flightsearch" type="radio"  id="button2" /> Round Way</label>
			<!--<button id="button2" type="button" href="#roundtrip" class="btn btn-primary">Round-trip</button>-->
			</div>
                    </div>
                    <div class="section row-fluid span3"><div class="btn-group"><label for="button3"><input name="flightsearch" type="radio"  id="button3" /> Search All Flights</label>
			<!--<button id="button3" type="button" href="#all" class="btn btn-primary">Search all flights</button>-->
			</div>
                    </div>
                    
          </div>
          
          
          <div class="section row-fluid  span12 greybackground"  id="oneway">          
             
		<form role="form" action="index.php" method="POST">
		  
		  <div class="section row-fluid span6">
		    <label for="from">Depart From:</label>
		    <input type="text" class="form-control" id="from" name="from" placeholder="Example: DEL" required>
		  </div>
		  <div class="section row-fluid span6">
		    <label for="to">Arrive To:</label>
		    <input type="text" class="form-control" id="to" name="to" placeholder="Example: YYZ" required>
		  </div>
		 
		
		 
			  <div class="section row-fluid span6">
			    <label for="depart">Travel Date:</label>
			    <input type="date" class="form-control" id="depart" name="depart" paceholder="DD/MM/YYYY format" required>
			  </div>
		   
		   
		  <div class="section row-fluid span6">
		    <label for="class">Class:</label>
		    <select class="form-control" name="class">
		      <option value="Economy">Economy</option>
		      <option value="Business">Business</option>   
		    </select>
		  </div> 
		  
		  
		  <div class="section row-fluid span8"> 
		    <label class="radio-inline">
		      <input type="radio" name="stop" value="nonstop" checked>&nbsp;Non-Stop
		    </label>
		    <label class="radio-inline">
		      <input type="radio" name="stop" value="1stop">&nbsp;One Stop
		    </label>
		  </div> 
		 
		  <div class="btn-group btn-group-justified section row-fluid span2">	
				<input type="submit" name="one-way-search" value="Search" class=" uibutton loading searchbutton"/>
					
		  </div>
          
         
          
		</form>
	</div>      
			
            
            
            
            
            <div id="roundtrip" class="section row-fluid  span12 greybackground">   		
            
		<form role="form" action="index.php" method="POST">
			 
			  <div class="section row-fluid span6">
			    <label for="from">Depart From:</label>
			    <input type="text" class="form-control" id="from" name="from" placeholder="Example: DEL " required>
			  </div>
			  <div class="section row-fluid span6">
			    <label for="to">Arrive To:</label>
			    <input type="text" class="form-control" id="to" name="to" placeholder="Example: YYZ" required>
			  </div>
			
			 
			  <div class="section row-fluid span6">
			    <label for="depart">Travel Departure Date:</label>
			    <input type="date" class="form-control" id="depart" name="depart" required>
			  </div>  
			  <div class="section row-fluid span6">
			    <label for="return">Travel Return Date:</label>
			    <input type="date" class="form-control" id="return" name="return" required>
			  </div>
			
			    
			  <div class="section row-fluid span6">
			    <label for="class">Class:</label>
			    <select class="form-control" name="class">
			      <option value="Economy">Economy</option>
			      <option value="Business">Business</option>   
			    </select>
			  </div> 
			
			  <div class="form-group section row-fluid span6"> 
			    <label class="radio-inline">
			      <input type="radio" name="stop" value="nonstop" checked>&nbsp;Non-Stop
			    </label>   
			  </div> 
			  <div class="btn-group btn-group-justified section row-fluid span2">	
				
				<input type="submit" name="round-search" value="Search" class=" uibutton loading searchbutton"/>
				</div>
				<!--<div class="btn-group section row-fluid span2">
					<button type="reset"  class="btn btn-info" value="Reset">Reset</button>
				</div>-->
		  	
			</form>
	</div>       
           

	


	
	<div id="all" class="section row-fluid  span12 greybackground"> 
		<form role="form" action="index.php" method="POST">
			 
			  <div class="section row-fluid span6">
			  <label for="selectdate">Select Travel Date:</label>
			  <input type="date" class="form-control" id="selectdate" name="selectdate" required>
			  </div>
			 
			  
			  <div class="section row-fluid span6">
			 <input type="submit" name="allsearch" value="Search" class=" uibutton loading searchbutton"/>
			  </div>
			
			</form>
			</div>
		

	
<!--End CBD Search Box------>


                                <!--  end widget-content -->
                            </div><!-- widget  span12 clearfix-->

                    </div>
                 <!-----------------CBD top Search block end------------------->





<!---Start ONE way CBD result---->
<?php //print_r($_POST);
if($_POST){
//---one way start---------
if(isset($_POST['one-way-search']) && $_POST['one-way-search']=='Search'){
	
?>
<div class="row-fluid">
        <div class="widget  span12 clearfix">
        <div class="widget-header">
        <span><i class="icon-home"></i> Flights Search Result : One Way</span>
        </div><!-- End widget-header -->
        
        <div class="widget-content">
<?php
	function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}


$from = test_input($_POST["from"]);
$to = test_input($_POST["to"]);
$departdate = $_POST["depart"];
$class = $_POST["class"];
$stop = $_POST["stop"];

global $sql1,$sql2,$result, $availableNumber;

  //non-stop
  if($stop=="nonstop"){
    
    //search by (code and code) or (airport_city and airport_city)
    $sql1 = "SELECT FL.flight_number AS FLnumber, airline_name, aircraft, departure, d_time, arrival, a_time, C.name AS classname, seats, price, COUNT(*)
            FROM cbd_flights FL,  cbd_class_type C, cbd_airlines AP , cbd_airports A
            WHERE (FL.flight_number = C.flight_number) AND (FL.airplane_id = AP.ID) AND C.name = '$class' AND            
           ((((airport_city LIKE '%$from%') AND (airport_code = departure)) OR  ((airport_city LIKE '%$to%') AND (airport_code = arrival)))
           OR (((departure LIKE '%$from%') AND (arrival LIKE '%$to%'))) )
            GROUP BY FL.flight_number
            HAVING COUNT(*)>1
            ORDER BY FL.flight_number";
    $result = mysql_query($sql1);
$gurjeet_sql="SELECT F.flight_number AS FLnumber, airline_name, aircraft, departure, d_time, arrival, a_time, C.name AS classname, seats, price, COUNT(*)<br>
            FROM cbd_flights F,  cbd_class_type C, cbd_airlines AP , cbd_airports A<br>
            WHERE (F.flight_number = C.flight_number) AND (F.airplane_id = AP.ID) AND C.name = '$class' AND <br>           
           ((((airport_city LIKE '%$from%') AND (airport_code = departure)) OR  ((airport_city LIKE '%$to%') AND (airport_code = arrival)))
           OR (((departure LIKE '%$from%') AND (arrival LIKE '%$to%'))) )<br>
            GROUP BY F.flight_number<br>
            HAVING COUNT(*)>1<br>
            ORDER BY F.flight_number";
    if(mysql_num_rows($result))
      { $result = mysql_query($sql1);}
    else{
      //search by (code and city) or (airport_city and code)
      $sql2 = "SELECT FL.flight_number AS FLnumber, airline_name, aircraft, departure, d_time, arrival, a_time, C.name AS classname, seats, price
            FROM cbd_flights FL,  cbd_class_type C, cbd_airlines AP , cbd_airports A
            WHERE (FL.flight_number = C.flight_number) AND (FL.airplane_id = AP.ID) AND C.name = '$class' AND            
           ((((airport_city LIKE '%$from%') AND (airport_code = departure)) AND (arrival LIKE '%$to%'))
           OR ((departure LIKE '%$from%') AND ((airport_city LIKE '%$to%') AND (airport_code = arrival)))  )
            GROUP BY FL.flight_number            
            ORDER BY FL.flight_number";
      $result = mysql_query($sql2);
	  
	  $gurjeet_sql="SELECT F.flight_number AS FLnumber, airline_name, aircraft, departure, d_time, arrival, a_time, C.name AS classname, seats, price<br>
            FROM cbd_flights F,  cbd_class_type C, cbd_airlines AP , cbd_airports A<br>
            WHERE (F.flight_number = C.flight_number) AND (F.airplane_id = AP.ID) AND C.name = '$class' AND            
           ((((airport_city LIKE '%$from%') AND (airport_code = departure)) AND (arrival LIKE '%$to%'))
           OR ((departure LIKE '%$from%') AND ((airport_city LIKE '%$to%') AND (airport_code = arrival)))  )<br>
            GROUP BY F.flight_number    <br>        
            ORDER BY F.flight_number";
    }



    $rowcount = mysql_num_rows($result);


    if($rowcount == 0){
        echo "<div class='alert alert-info'><strong>Search Result: </strong>".$rowcount." flight</div>";
    }
    else{
   // echo "<div class='alert alert-info'><strong>Search Result: </strong>".$rowcount." flight(s) found</div>";
    echo "<div class='alert alert-info'>One Way Search Result ".$rowcount." Found: $from - $to On ".$_POST["depart"]." ".$_POST["class"]." Class Non-Stop </div>";




    echo "<table class='table table-bordered table-striped table-hover'  id='dataTable'>
          <thead>
          <tr>
            <th>Flight</th>
            <th>Aircraft</th>
            <th>Date</th>
            <th>Departure</th>
            <th>Departure Time</th>
            <th>Arrival</th>
            <th>Arrival Time</th>
            <th>Class</th>
            <th>Total Seats</th>
            <th>Price</th>
            <th>Seats Available</th>
            <th>Book Now</th>
          </tr>
          </thead>";
    while($row = mysql_fetch_array($result)) {
        echo "<tbody><tr>";
        echo "<td>" . $row['FLnumber'] . "</td>";
        echo "<td>" . $row['airline_name']." ".$row['aircraft']. "</td>";
        echo "<td>" . $departdate . "</td>";
        echo "<td>" . $row['departure'] . "</td>";
        echo "<td>" . $row['d_time'] . "</td>";
        echo "<td>" . $row['arrival'] . "</td>";
        echo "<td>" . $row['a_time'] . "</td>";
        echo "<td>" . $row['classname'] . "</td>";
        echo "<td>" . $row['seats'] . "</td>";
        echo "<td>" . $row['price'] . "</td>";
        
       
            //calculate number of remain seats
            $seatreserved = "SELECT flightno, classtype, COUNT(*)
                        FROM cbd_ticket_booking B
                        WHERE B.date = '".$departdate."' AND B.flightno = '".$row['FLnumber']."'AND B.classtype ='".$row['classname']."' AND paid=1
                        GROUP BY flightno, classtype";
            $reserved = mysql_query($seatreserved);   
            $reservedNumber = mysql_fetch_array($reserved);
            
            $seats = mysql_query("SELECT seats FROM cbd_class_type C WHERE C.flight_number='".$row['FLnumber']."' AND C.name= '".$row['classname']."'");
            $seatsNumber = mysql_fetch_array($seats);


            if(mysql_num_rows($reserved)>0){            
                $availableNumber = $seatsNumber['seats'] - $reservedNumber['COUNT(*)'];
            }else{
                $availableNumber = $seatsNumber['seats'];
            }
        
            echo "<td>".$availableNumber."</td>";
        
        if($availableNumber>0){
        echo '<td>
            <form action="shoppingcart.php" method="post">
            <input type="hidden" name="flightno" value="'.$row['FLnumber'].'">
            <input type="hidden" name="classtype" value="'.$row['classname'].'">
            <input type="hidden" name="price" value="'.$row['price'].'">
            <input type="hidden" name="date" value="'.$departdate.'">
            <input type="hidden" name="type" value="onewaynonstop">
            <button type="submit" class="uibutton">Pay Now</button>
            </form>
            </td>';
        }else{
            echo "<td><button type='button' class='btn btn-warning' onclick='myFunction()'>Not Available</button></td>";
        }
        
        echo "</tr>";
    }
    echo " </tbody></table>";

    }

  }
  else{

    //1 stop
    //search by code and code only
    $sql3 = "SELECT FL.flight_number AS FLnumber, airline_name, aircraft, departure, d_time, arrival, a_time, C.name AS classname, seats, price
            FROM cbd_flights FL,  cbd_class_type C, cbd_airlines AP 
            WHERE (FL.flight_number = C.flight_number) AND (FL.airplane_id = AP.ID) AND C.name = '$class' AND            
           (departure = '$from') AND arrival IN
           (SELECT departure FROM cbd_flights FL,  cbd_class_type C, cbd_airlines AP 
           WHERE (FL.flight_number = C.flight_number) AND (FL.airplane_id = AP.ID) AND C.name = '$class' AND arrival = '$to')
          
           ORDER BY FL.flight_number";
		   
		$gurjeet_sql="SELECT F.flight_number AS FLnumber, airline_name, aircraft, departure, d_time, arrival, a_time, C.name AS classname, seats, price<br>
            FROM cbd_flights F,  cbd_class_type C, cbd_airlines AP <br>
            WHERE (F.flight_number = C.flight_number) AND (F.airplane_id = AP.ID) AND C.name = '$class' AND            
           (departure = '$from')<br> AND arrival IN
           (SELECT departure FROM cbd_flights F,  cbd_class_type C, cbd_airlines AP 
           WHERE (F.flight_number = C.flight_number) AND (F.airplane_id = AP.ID) AND C.name = '$class' AND arrival = '$to')<br>
          
           ORDER BY F.flight_number";   
		
    $result3 = mysql_query($sql3);

    $rowcount3 = mysql_num_rows($result3);


    if($rowcount3 == 0){
        echo "<div class='alert alert-info'><strong>Search Result: </strong>".$rowcount3." result</div>";
    }
    else{
         echo "<div class='alert alert-info'>One Way Search Result : $from - $to On ".$_POST["depart"]." ".$_POST["class"]." Class with 1 Stop </div>";



    while($row = mysql_fetch_array($result3)) {
       
       
            //calculate number of remain seats
            $seatreserved = "SELECT flightno, classtype, COUNT(*)
                        FROM cbd_ticket_booking B
                        WHERE B.date = '".$departdate."' AND B.flightno = '".$row['FLnumber']."'AND B.classtype ='".$row['classname']."' AND paid=1
                        GROUP BY flightno, classtype";
            $reserved = mysql_query($seatreserved);   
            $reservedNumber = mysql_fetch_array($reserved);
            
            $seats = mysql_query("SELECT seats FROM cbd_class_type C WHERE C.flight_number='".$row['FLnumber']."' AND C.name= '".$row['classname']."'");
            $seatsNumber = mysql_fetch_array($seats);


            if(mysql_num_rows($reserved)>0){            
                $availableNumber = $seatsNumber['seats'] - $reservedNumber['COUNT(*)'];
            }else{
                $availableNumber = $seatsNumber['seats'];
            }
        
            // echo "<td>".$availableNumber."</td>";
            // echo "<td></td>";
            // echo "</tr>";

 //echo the 1 stop flight
    $sql4 = "SELECT FL.flight_number AS FLnumber, airline_name, aircraft, departure, d_time, arrival, a_time, C.name AS classname, seats, price
            FROM cbd_flights FL,  cbd_class_type C, cbd_airlines AP 
            WHERE (FL.flight_number = C.flight_number) AND (FL.airplane_id = AP.ID) AND C.name = '$class' AND            
           (departure = '".$row['arrival']."')  AND (arrival = '$to')                 
            ORDER BY FL.flight_number";
			
			$gurjeet_sql="SELECT F.flight_number AS FLnumber, airline_name, aircraft, departure, d_time, arrival, a_time, C.name AS classname, seats, price
            <br>FROM cbd_flights F,  cbd_class_type C, cbd_airlines AP 
            <br>WHERE (F.flight_number = C.flight_number) AND (F.airplane_id = AP.ID) AND C.name = '$class' AND            
           (departure = '".$row['arrival']."')  AND (arrival = '$to')                 
           <br> ORDER BY F.flight_number";
			
    $result4 = mysql_query($sql4);

     $rowcount4 = mysql_num_rows($result4);

     $rowtotal = $rowcount3*$rowcount4;

     if($rowtotal==0){
        echo "<div class='alert alert-info'><strong>Search Result: </strong>".$rowtotal." result</div>";
     }else{
        


    echo "<table class='table table-bordered table-striped table-hover'  id='dataTable'>
          <thead>
          <tr>
            <th>Flight</th>
            <th>Aircraft</th>
            <th>Date</th>
            <th>Departure From</th>
            <th>Departure Time</th>
            <th>Arrival To</th>
            <th>Arrival Time</th>
            <th>Class</th>
            <th>Total Seats</th>
            <th>Price</th>
            <th>Seats Available</th>
            <th>Book Now</th>
          </tr>
          </thead>";



       while($row4 = mysql_fetch_array($result4)){
             echo "<tbody>";
        echo "<tr>";
        echo "<td>" . $row['FLnumber'] . "</td>";
        echo "<td>" . $row['airline_name']." ".$row['aircraft']. "</td>";
         echo "<td>" . $departdate . "</td>";
        echo "<td>" . $row['departure'] . "</td>";
        echo "<td>" . $row['d_time'] . "</td>";
        echo "<td>" . $row['arrival'] . "</td>";
        echo "<td>" . $row['a_time'] . "</td>";
        echo "<td>" . $row['classname'] . "</td>";
        echo "<td>" . $row['seats'] . "</td>";
        echo "<td>" . $row['price'] . "</td>";
        echo "<td>".$availableNumber."</td>";
        echo "<td></td>";
        echo "</tr>";

        echo "<tr>";
        echo "<td>" . $row4['FLnumber'] . "</td>";
        echo "<td>" . $row4['airline_name']." ".$row4['aircraft']. "</td>";
         echo "<td>" . $departdate . "</td>";
        echo "<td>" . $row4['departure'] . "</td>";
        echo "<td>" . $row4['d_time'] . "</td>";
        echo "<td>" . $row4['arrival'] . "</td>";
        echo "<td>" . $row4['a_time'] . "</td>";
        echo "<td>" . $row4['classname'] . "</td>";
        echo "<td>" . $row4['seats'] . "</td>";
        echo "<td>" . $row4['price'] . "</td>";


         //calculate number of remain seats
            $seatreserved4 = "SELECT flightno, classtype, COUNT(*)
                        FROM cbd_ticket_booking B
                        WHERE B.date = '".$departdate."' AND B.flightno = '".$row4['FLnumber']."'AND B.classtype ='".$row4['classname']."' AND paid=1
                        GROUP BY flightno, classtype";
            $reserved4 = mysql_query($seatreserved4);   
            $reservedNumber4 = mysql_fetch_array($reserved4);
            
            $seats4 = mysql_query("SELECT seats FROM cbd_class_type C WHERE C.flight_number='".$row4['FLnumber']."' AND C.name= '".$row4['classname']."'");
            $seatsNumber4 = mysql_fetch_array($seats4);


            if(mysql_num_rows($reserved4)>0){            
                $availableNumber4 = $seatsNumber4['seats'] - $reservedNumber4['COUNT(*)'];
            }else{
                $availableNumber4 = $seatsNumber4['seats'];
            }
        
            echo "<td>".$availableNumber4."</td>";
            

            //add to cart
            if($availableNumber>0 && $availableNumber4 >0){
            echo '<td>
            <form action="shoppingcart.php" method="post">
            <input type="hidden" name="flightno" value="'.$row['FLnumber'].'">
            <input type="hidden" name="classtype" value="'.$row['classname'].'">
            <input type="hidden" name="price" value="'.$row['price'].'">
            <input type="hidden" name="flightno2" value="'.$row4['FLnumber'].'">
            <input type="hidden" name="classtype2" value="'.$row4['classname'].'">
            <input type="hidden" name="price2" value="'.$row4['price'].'">
            <input type="hidden" name="date" value="'.$departdate.'">
            <input type="hidden" name="type" value="oneway1stop">
            <button type="submit" class="uibutton">Pay Now</button>
            </form>
            </td>';
            }else{
                echo "<td><button type='button' class='btn btn-warning' onclick='myFunction()'>Not Available</button></td>";
            }
        echo "</tr>";
      }
    echo " </tbody></table>";
    }
    
    }

    }


  }echo "<div class='sqlbox'><b>SQL QUERY USED:</b> <br>".$gurjeet_sql."</div>";
 ?>
</div><!---end widget-content-->
        </div><!-- widget  span12 clearfix-->
</div>
 <?php
}/////one way end here





//---Round trip start---------
if(isset($_POST['round-search']) && $_POST['round-search']=='Search'){
	
?>
<div class="row-fluid">
        <div class="widget  span12 clearfix">
        <div class="widget-header">
        <span><i class="icon-home"></i> Flights Search Result : Round Way </span>
        </div><!-- End widget-header -->
        
        <div class="widget-content">
<?php

function test_input($data) {
   $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
}


$from = test_input($_POST["from"]);
$to = test_input($_POST["to"]);
$depart = $_POST["depart"];
$return = $_POST["return"];
$class = $_POST["class"];


global $sql,$sql2, $availableNumber;

    //search by code only, non-stop
    $sql = "SELECT FL.flight_number AS FLnumber, airline_name, aircraft, departure, d_time, arrival, a_time, C.name AS classname, seats, LPAD(price,6,' ') as price
            FROM cbd_flights FL,  cbd_class_type C, cbd_airlines AP , cbd_airports A
            WHERE (FL.flight_number = C.flight_number) AND (FL.airplane_id = AP.ID) AND C.name = '$class' AND
            ((departure = '$from') AND (arrival = '$to'))
            GROUP BY FL.flight_number            
            ORDER BY FL.flight_number";
    $result = mysql_query($sql);

    
    $rowcount = mysql_num_rows($result);
$gurjeet_sql='';
$gurjeet_sql="SELECT F.flight_number AS FLnumber, airline_name, aircraft, departure, d_time, arrival, a_time, C.name AS classname, seats, LPAD(price,6,' ') as price<br>
            FROM cbd_flights F,  cbd_class_type C, cbd_airlines AP , cbd_airports A
            <br>WHERE (F.flight_number = C.flight_number) AND (F.airplane_id = AP.ID) AND C.name = '$class' AND
            ((departure = '$from') AND (arrival = '$to'))
           ";
    //search return flight

    $sql2 = "SELECT FL.flight_number AS FLnumber, airline_name, aircraft, departure, d_time, arrival, a_time, C.name AS classname, seats, LPAD(price,6,' ') as price
            FROM cbd_flights FL,  cbd_class_type C, cbd_airlines AP , cbd_airports A
            WHERE (FL.flight_number = C.flight_number) AND (FL.airplane_id = AP.ID) AND C.name = '$class' AND
            ((departure = '$to') AND (arrival = '$from'))
             GROUP BY FL.flight_number            
            ORDER BY FL.flight_number";
			
$gurjeet_sql.= "<br>UNION <br>"."SELECT F.flight_number AS FLnumber, airline_name, aircraft, departure, d_time, arrival, a_time, C.name AS classname, seats, LPAD(price,6,' ') as price<br>
            FROM cbd_flights F,  cbd_class_type C, cbd_airlines AP , cbd_airports A<br>
            WHERE (F.flight_number = C.flight_number) AND (F.airplane_id = AP.ID) AND C.name = '$class' AND
            ((departure = '$to') AND (arrival = '$from'))<br>
            ";
    $result2 = mysql_query($sql2);

     $rowcount2 = mysql_num_rows($result2);

    $rowtotal = $rowcount*$rowcount2;

    if($rowtotal == 0){
        echo "<div class='alert alert-info'><strong>Search Result: </strong>".$rowtotal." result</div>";
    }
    else{
    echo "<div class='alert alert-info'><strong>Search Result: </strong>".$rowtotal." result(s)</div>";

    echo "<table class='table table-bordered table-striped table-hover' id='dataTable-'>
          <thead>
          <tr>
            <th>Flight</th>
            <th>Aircraft</th>
            <th>Date</th>
            <th>Departure From</th>
            <th>Departure Time</th>
            <th>Arrival To</th>
            <th>Arrival Time</th>
            <th>Class</th>
            <th>Total Seats</th>
            <th>Price</th>
            <th>Seats Available</th>
            <th>Book Now</th>
          </tr>
          </thead>";
    while($row = mysql_fetch_array($result)) {
        echo "<tbody>";
       
        // echo "<tr>";
        // echo "<td>" . $row['FLnumber'] . "</td>";
        // echo "<td>" . $row['company']." ".$row['type']. "</td>";
        // echo "<td>" . $depart . "</td>";
        // echo "<td>" . $row['departure'] . "</td>";
        // echo "<td>" . $row['d_time'] . "</td>";
        // echo "<td>" . $row['arrival'] . "</td>";
        // echo "<td>" . $row['a_time'] . "</td>";
        // echo "<td>" . $row['classname'] . "</td>";
        // echo "<td>" . $row['seats'] . "</td>";
        // echo "<td>" . $row['price'] . "</td>";
        
       
            //calculate number of remain seats
            $seatreserved = "SELECT flightno, classtype, COUNT(*)
                        FROM cbd_ticket_booking B
                        WHERE B.date = '".$depart."' AND B.flightno = '".$row['FLnumber']."'AND B.classtype ='".$row['classname']."' AND paid=1
                        GROUP BY flightno, classtype";
            $reserved = mysql_query($seatreserved);   
            $reservedNumber = mysql_fetch_array($reserved);
            
            $seats = mysql_query("SELECT seats FROM cbd_class_type C WHERE C.flight_number='".$row['FLnumber']."' AND C.name= '".$row['classname']."'");
            $seatsNumber = mysql_fetch_array($seats);


            if(mysql_num_rows($reserved)>0){            
                $availableNumber = $seatsNumber['seats'] - $reservedNumber['COUNT(*)'];
            }else{
                $availableNumber = $seatsNumber['seats'];
            }
        
            // echo "<td>".$availableNumber."</td>";
            // echo "<td></td>";
            // echo "</tr>";

    $result2 = mysql_query($sql2);
    $rowcount2 = mysql_num_rows($result2);
    
    if($rowcount2>0){
        while($row2 = mysql_fetch_array($result2)){

        echo "<tr>";
        echo "<td>" . $row['FLnumber'] . "</td>";
        echo "<td>" . $row['airline_name']." ".$row['aircraft']. "</td>";
        echo "<td>" . $depart . "</td>";
        echo "<td>" . $row['departure'] . "</td>";
        echo "<td>" . $row['d_time'] . "</td>";
        echo "<td>" . $row['arrival'] . "</td>";
        echo "<td>" . $row['a_time'] . "</td>";
        echo "<td>" . $row['classname'] . "</td>";
        echo "<td>" . $row['seats'] . "</td>";
        echo "<td>" . $row['price'] . "</td>";
        echo "<td>".$availableNumber."</td>";
        echo "<td></td>";
        echo "</tr>";














        echo "<tr>";
        echo "<td>" . $row2['FLnumber'] . "</td>";
        echo "<td>" . $row2['airline_name']." ".$row2['aircraft']. "</td>";
        echo "<td>" . $return . "</td>";
        echo "<td>" . $row2['departure'] . "</td>";
        echo "<td>" . $row2['d_time'] . "</td>";
        echo "<td>" . $row2['arrival'] . "</td>";
        echo "<td>" . $row2['a_time'] . "</td>";
        echo "<td>" . $row2['classname'] . "</td>";
        echo "<td>" . $row2['seats'] . "</td>";
        echo "<td>" . $row2['price'] . "</td>";


         //calculate number of remain seats
            $seatreserved4 = "SELECT flightno, classtype, COUNT(*)
                        FROM cbd_ticket_booking B
                        WHERE B.date = '".$return."' AND B.flightno = '".$row2['FLnumber']."'AND B.classtype ='".$row2['classname']."' AND paid=1
                        GROUP BY flightno, classtype";
            $reserved4 = mysql_query($seatreserved4);   
            $reservedNumber4 = mysql_fetch_array($reserved4);
            
            $seats4 = mysql_query("SELECT seats FROM cbd_class_type C WHERE C.flight_number='".$row2['FLnumber']."' AND C.name= '".$row2['classname']."'");
            $seatsNumber4 = mysql_fetch_array($seats4);


            if(mysql_num_rows($reserved4)>0){            
                $availableNumber4 = $seatsNumber4['seats'] - $reservedNumber4['COUNT(*)'];
            }else{
                $availableNumber4 = $seatsNumber4['seats'];
            }
        
            echo "<td>".$availableNumber4."</td>";


        if($availableNumber>0 && $availableNumber4>0){
        echo '<td>
            <form action="shoppingcart.php" method="post">
            <input type="hidden" name="flightno" value="'.$row['FLnumber'].'">
            <input type="hidden" name="classtype" value="'.$row['classname'].'">
            <input type="hidden" name="price" value="'.$row['price'].'">
            <input type="hidden" name="date" value="'.$depart.'">
            <input type="hidden" name="flightno2" value="'.$row2['FLnumber'].'">
            <input type="hidden" name="classtype2" value="'.$row2['classname'].'">
            <input type="hidden" name="price2" value="'.$row2['price'].'">
            <input type="hidden" name="date2" value="'.$return.'">
            <input type="hidden" name="type" value="roundtrip">
            <button type="submit" class="uibutton">Pay Now</button>
            </form>
            </td>';
        }else{
            echo "<td><button type='button' class='btn btn-warning' onclick='myFunction()'>Not Available</button></td>";
        }

           
        
        echo "</tr>";

    } 



    }

    
    

    }
    echo " </tbody></table>";
  }
echo "<div class='sqlbox'><b>SQL QUERY USED:</b> <br>".$gurjeet_sql."</div>";

 ?>
</div><!---end widget-content-->
        </div><!-- widget  span12 clearfix-->
</div>
 <?php
}// round search end



//---All search start---------
if(isset($_POST['allsearch']) && $_POST['allsearch']=='Search'){
	
?>
<div class="row-fluid">
        <div class="widget  span12 clearfix">
        <div class="widget-header">
        <span><i class="icon-home"></i> All Flights Search Result </span>
        </div><!-- End widget-header -->
        
        <div class="widget-content">
<?php


$selectdate = $_POST["selectdate"];


global $sql, $availableNumber;

    $sql = "SELECT * 
            FROM cbd_flights FL,  cbd_class_type C, cbd_airlines AP 
            WHERE (FL.flight_number = C.flight_number) AND (FL.airplane_id = AP.ID) 
            
            ORDER BY FL.flight_number";
			
$gurjeet_sql="SELECT * <br>
            FROM cbd_flights ,  cbd_class_type , cbd_airlines  <br>
            WHERE (cbd_flights.flight_number = cbd_class_type.flight_number) AND (cbd_flights.airplane_id = cbd_airlines.ID) <br>
            
            ORDER BY cbd_flights.flight_number";

$result = mysql_query($sql);
$rowcount = mysql_num_rows($result);


if($rowcount == 0){
    echo "<div class='alert alert-info'><strong>Search Result: </strong>".$rowcount." result</div>";
}
else{
echo "<div class='alert alert-info'><strong>Search Result: </strong>".$rowcount." results</div>";

echo "<table class='table table-bordered table-striped table-hover' id='dataTable'>
      <thead>
      <tr>
        <th>Flight</th>
        <th>Aircraft</th>
        <th>Date</th>
        <th>Departure</th>
        <th>Departure Time</th>
        <th>Arrival</th>
        <th>Arrival Time</th>
        <th>Class</th>
        <th>Total Seats</th>
        <th>Price</th>
        <th>Seats Available</th>
        <th>Book NOw</th>
      </tr>
      </thead>";
while($row = mysql_fetch_array($result)) {
    echo "<tbody><tr>";
    echo "<td>" . $row['flight_number'] . "</td>";
    echo "<td>" . $row['airline_name']." ".$row['aircraft']. "</td>";
    echo "<td>" . $selectdate . "</td>";
    echo "<td>" . $row['departure'] . "</td>";
    echo "<td>" . $row['d_time'] . "</td>";
    echo "<td>" . $row['arrival'] . "</td>";
    echo "<td>" . $row['a_time'] . "</td>";
    echo "<td>" . $row['name'] . "</td>";
    echo "<td>" . $row['seats'] . "</td>";
    echo "<td>" . $row['price'] . "</td>";
    
   
        //calculate number of remain seats
        $seatreserved = "SELECT flightno, classtype, COUNT(*)
                    FROM cbd_ticket_booking B
                    WHERE B.date = '".$selectdate."' AND B.flightno = '".$row['flight_number']."'AND B.classtype ='".$row['name']."' AND paid=1
                    GROUP BY flightno, classtype";
        $reserved = mysql_query($seatreserved);   
        $reservedNumber = mysql_fetch_array($reserved);
        
        $seats = mysql_query("SELECT seats FROM cbd_class_type C WHERE C.flight_number='".$row['flight_number']."' AND C.name= '".$row['name']."'");
        $seatsNumber = mysql_fetch_array($seats);


        if(mysql_num_rows($reserved)>0){            
            $availableNumber = $seatsNumber['seats'] - $reservedNumber['COUNT(*)'];
        }else{
            $availableNumber = $seatsNumber['seats'];
        }
    
        echo "<td>".$availableNumber."</td>";
    
    if($availableNumber>0){
    echo '<td>
        <form action="shoppingcart.php" method="post">
        <input type="hidden" name="flightno" value="'.$row['flight_number'].'">
        <input type="hidden" name="classtype" value="'.$row['name'].'">
        <input type="hidden" name="price" value="'.$row['price'].'">
        <input type="hidden" name="date" value="'.$selectdate.'">
        <input type="hidden" name="type" value="all">
        <button type="submit" class="uibutton">Pay Now</button>
        </form>
        </td>';
    }else{
        echo "<td><button type='button' class='btn btn-warning' onclick='myFunction()'>Not Available</button></td>";
    }
    
    echo "</tr>";
}
echo " </tbody></table>";

echo "<div class='sqlbox'><b>SQL QUERY USED:</b> <br>".$gurjeet_sql."</div>";

 ?>
</div><!---end widget-content-->
        </div><!-- widget  span12 clearfix-->
</div>
 <?php
}
}// all search end


}?>
<!---End One Way CBD result----->





                </div> <!--// End inner -->
				
              </div> <!--// End ID content -->

  </body>
        </html>