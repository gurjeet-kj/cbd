﻿<?php include('header.php');
include('leftmenu.php');
if($_POST){
//---one way start---------
if(isset($_POST['login']) && $_POST['login']=='Login'){

$username=$_POST['username'];
	$pwd=$_POST['pwd'];
	$res=mysql_query("SELECT * FROM cbd_passengers WHERE username='$username'");
	$row=mysql_fetch_array($res);
	if($row['password']==$pwd)
	{
		$_SESSION['user']=$row['username'];$_SESSION["admin_name"]=$row['firstname'];
		echo "<script language='javascript'>\n";
echo "window.location='index.php';";
echo "</script>";
	}
	else
	{echo "<h2>Login Credentials Not Matched. Please Try Again later.</h2>";}
	
}
}

/*if(!isset($_SESSION['user'])){
    header("Location: signin.php");
}else{
    $user = $_SESSION['user'];	

$ticket_number=date('Hisdmy');
 $sql = mysql_query("UPDATE cbd_ticket_booking
            SET paid = '1', ticket_number=".$ticket_number."
            WHERE username = '$user' AND paid = '0'");



$sql = "SELECT ticket_number,FL.flight_number AS FLnumber, airline_name, aircraft, B.ID AS bookid, time, B.date,  departure, d_time, arrival, a_time, C.name AS classname, seats, price
            FROM cbd_flights FL,  cbd_class_type C, cbd_airlines AP , cbd_ticket_booking B
            WHERE (FL.flight_number = C.flight_number) AND (B.flightno = C.flight_number) AND (classtype = C.name) AND (FL.airplane_id = AP.ID) 
            AND  B.username = '$user' AND paid = '1' AND ticket_number='".$ticket_number."'
            ORDER BY time";

//echo $sql;
$result = mysql_query($sql);
$rowcount = mysql_num_rows($result);
}*/
?>
<style>#content{ height:100vh;}#login{border:none;}
</style>
  <!----start-->
   <body class="frontpage">
         
        <div id="successLogin"></div>
        <div class="text_success"><img src="images/loadder/loader_green.gif"  alt="ziceAdmin" /><span>Please wait</span></div>
        
        <div id="login">
          <div class="ribbon"></div>
          <div class="inner clearfix image">
          <div class="logo"><p align="center" style="font-size:25px"><img src="images/logo.png" width="150"/></p>
</div>
          <div class="formLogin"><h4>Customer Login</h4>
         <form name="formLogin"  id="formLogin" method="post" action="signin.php">
      
                <div class="tip">
                      <input name="username" type="text"  id="username_id"  title="Username (case sensitive)" />
                </div>
                <div class="tip">
                      <input name="pwd" type="password" id="password"   title="Password (case sensitive)" />
                </div>
      			
                <div class="loginButton">
               
                  <div class=" pull-right" >
                      <div class="btn-group">
                        <input type="submit" class="btn" id="but_login" value="Login" name="login">&nbsp;&nbsp;&nbsp;
			        <!--<button type="button" class="btn" id="forgetpass"> Forget Pass</button>-->                    
			  </div>
                  </div>
                  <div class="clear"></div>
                </div>
      
          </form>
       
          </div>
        </div>
          <div class="shadow"></div>
        </div>
        
        <!--Login div-->
        <div class="clear"></div>
        
        
        <!-- Link JScript-->
        <script type="text/javascript" src="js/jquery.min.js"></script>
        <script type="text/javascript" src="components/ui/jquery.ui.min.js"></script>
        <script type="text/javascript" src="components/form/form.js"></script>
        <script type="text/javascript" src="js/login.js"></script>
		<script type="text/javascript" >
        $(document).ready(function () {	 
               /* $('#createacc').click(function(e){
                    $('#login').animate({   height: 350, 'margin-top': '-200px' }, 300);	
                    $('.formLogin').animate({   height: 240 }, 300);
                    $('#createaccPage').fadeIn();
                    $('#formLogin').hide();
                });*/
                $('#backLogin').click(function(e){
                    $('#login').animate({   height: 254, 'margin-top': '-148px' }, 300);	
                    $('.formLogin').animate({   height: 150 }, 300);
                    $('#formLogin').fadeIn();
                    $('#createaccPage').hide();
                });			
        });		
        </script>
        </body>
   <!----end--->
   
   
 
				 
            
				
  </body>
        </html>