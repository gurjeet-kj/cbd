<?php include('header.php');
include('leftmenu.php');
if($_POST){

$username = $_POST['username'];
 $firstname =$_POST['firstname'];
  $lastname =$_POST['lastname'];
   $tel =$_POST['tel'];
 $email = $_POST['email'];
 $pwd1 = $_POST['pwd1'];

 if(isset($_POST['middlename'])){
 	$middlename = $_POST['middlename'];
 }else{
 	$middlename = "";
 }

  if(isset($_POST['gender'])){
 	$gender = $_POST['gender'];
 }else{
 	$gender = "";
 }

  if(isset($_POST['birthday'])){
 	$birthday = $_POST['birthday'];
 }else{
 	$birthday = "";
 }



 if(mysql_query("INSERT INTO cbd_passengers(username,email,password,firstname,middlename,lastname,phone,gender,birthday,passport_number,passport_issue,passport_expiry,country_of_origin) VALUES('$username','$email','$pwd1','$firstname','$middlename','$lastname','$tel','$gender','$birthday','".$_POST['passport_number']."','".$_POST['passport_issue']."','".$_POST['passport_expiry']."','".$_POST['country_of_origin']."')"))
 {
  $_SESSION['user']=$username;$_SESSION["admin_name"]=$_POST['firstname'];
      /* echo "<script language='javascript'>\n";
echo "window.location='index.php';";
echo "</script>";*/
$gurjeet_sql="INSERT INTO cbd_passengers(username,email,password,firstname,middlename,lastname,phone,gender,birthday,passport_number,passport_issue,passport_expiry,country_of_origin) VALUES('$username','$email','$pwd1','$firstname','$middlename','$lastname','$tel','$gender','$birthday','".$_POST['passport_number']."','".$_POST['passport_issue']."','".$_POST['passport_expiry']."','".$_POST['country_of_origin']."')";
echo "<h2>You have sucessfully registered and loggedin !</h2>";
echo "<div class='sqlbox'><b>SQL QUERY USED:</b> <br>".$gurjeet_sql."</div>";

         }else{

echo "<h2>Tecnical Error. Please Try Again later.</h2>";
		 }
}
?>  
<script type="text/javascript">
            $(document).ready(function(){
//---------------------------------------	
$( "#emailid" ).keyup(function() {
	if(this.value.length>6){
		$.ajax({url: "ajax/email_exist_addclient.php",data: {email: this.value},success: function(data){	//alert(data);
				if(data==''){$('#emailexist').hide(); }else{$('#emailexist').html(data).show();}},
			});
	}
});

$( "#admin_name" ).keyup(function() {
	if(this.value.length>5){
		$.ajax({url: "ajax/company_exist_addclient.php",data: {email: this.value},success: function(data){	//alert(data);
				if(data==''){$('#admin_nameexist').hide(); }else{$('#admin_nameexist').html(data).show();}},
			});
	}
});
//--------------------------------------    
});
</script>
                <!-------------------table-------------->
                    <div class="row-fluid">
                    
                    		<!-- Widget -->
                            <div class="widget  span12 clearfix">
                            
                                <div class="widget-header">
                                    <span><i class="icon-bookmark"></i>Customer Registration</span> 
                                </div><!-- End widget-header -->	
                                
                                <div class="widget-content">    
        
                                <form id="validation_demo" action="signup.php" method="post"> 
                                <div class="row-fluid">
                                    
        
                                 <div class="span12"><div class="section "><label>First Name<small></small></label>   
                                     <div><input type="text" class="large" name="firstname" id="firstname" placeholder="First Name*"></div> </span></div>
								</div> 
                                
                                <div class="span12"><div class="section "><label>Middle Name<small></small></label>   
                                     <div><input type="text" class="large" name="middlename" id="middlename" placeholder="Middle Name"></div> <span id="admin_nameexist" class="green"></span></div>
								</div> 
                                
                                <div class="span12"><div class="section "><label>Last Name<small></small></label>   
                                     <div><input type="text" class="large" name="lastname" id="lastname" placeholder="Last Name*"></div> <span id="admin_nameexist" class="green"></span></div>
								</div> 
                                
                                
                                
                                
                                
                                
                               <div class="span12"><div class="section "><label>Email<small></small></label>   
                              <div><input type="text" class="large" name="email" id="email" placeholder="Email*"></div></div>
								</div>
                                
                                
                             <div class="span12"><div class="section "><label>Date Of Birth<small></small></label>   
                                     <div><input type="text" class="large" name="birthday" id="birthday" placeholder="Date Of Birth"></div> <span id="admin_nameexist" class="green"></span></div>
								</div> 
                                
                                <div class="span12"><div class="section "><label>Phone Number<small></small></label>   
                                     <div><input type="text" class="large" name="tel" id="tel" placeholder="Phone Number"></div> <span id="admin_nameexist" class="green"></span></div>
								</div> 
                                
                                
                                <div class="span12"><div class="section "><label>Passport Number<small></small></label>   
                                     <div><input type="text" class="large" name="passport_number" id="passport_number" placeholder="Passport Number"></div> <span id="admin_nameexist" class="green"></span></div>
								</div> 
                                
                                <div class="span12"><div class="section "><label>Passport Issue Date<small></small></label>   
                                     <div><input type="text" class="large" name="passport_issue" id="passport_issue" placeholder="Passport Issue Date: dd/mm/yyyy"></div> <span id="admin_nameexist" class="green"></span></div>
								</div> 
                                
                              <div class="span12"><div class="section "><label>Passport Expiry Date<small></small></label>   
                                     <div><input type="text" class="large" name="passport_expiry" id="passport_expiry" placeholder="Passport Expiry Date: dd/mm/yyyy"></div> <span id="admin_nameexist" class="green"></span></div>
								</div> 
                                  
                                <div class="span12"><div class="section "><label>Country Of origin<small></small></label>   
                                     <div><input type="text" class="large" name="country_of_origin" id="country_of_origin" placeholder="Country"></div> <span id="admin_nameexist" class="green"></span></div>
								</div> 
                                <div class="span12"><div class="section ">
                                                    <label>Gender<small></small></label>   
                                                    <div> 
                                                      <div>
                                 <label for="radio-2" >Male</label><input type="radio" name="gender" id="radio-2" value="Male"  class="ck" />
                                 <label for="radio-1" >Female</label><input type="radio" name="gender" id="radio-1" value="Female"  class="ck"  />
                                                      </div>
                                                    </div>
                                            </div></div>
								
								<div class="span12">			
                                            <div class="section">
                                                        <label> Login Details  <small></small></label>
                                                    <div>
                                            <input type="text"  placeholder="Username*" name="username" id="username"  class="validate[required,minSize[3],maxSize[20],] medium"  />
                                                        <span class="f_help"> Username login should be between 3 and not more than 20 characters.</span> 
                                                    </div>
                                                    <div>
                                              <input type="password" placeholder="Password*" class="validate[required,minSize[3]] medium"  name="pwd1" id="pwd1"  />														<span class="f_help"> Password should be atleast 3 characters.</span> 
                                                    </div>
                                            </div>
											
											
											
                                           
                                            
                                            
                                            
                                           
                                            
                                            
                                            
											</div>
											
                                           
                                            
                                            
                                            
											
											
                                            
                                            
											
											<!-----strt----->
                                            
										
											
			<script type="text/javascript">
			jQuery(document).ready(function() { $("#radio-4box").hide();$("#radio-5box").hide();$("#radio-6box").hide();
				 $("#radio-4").live('click',function(){$("#radio-4box").show();$("#radio-5box").hide();$("#radio-6box").hide();});
				 $("#radio-5").live('click',function(){$("#radio-5box").show();$("#radio-4box").hide();$("#radio-6box").hide();});
				 $("#radio-6").live('click',function(){$("#radio-6box").show();$("#radio-5box").hide();$("#radio-4box").hide();});

				 $("#fhs_amount2box").hide();$("#fhs_amount3box").hide();$("#fhs_amount4box").hide();$("#fhs_amount5box").hide();
				 $("#fhs_amount6box").hide();$("#fhs_amount7box").hide();$("#fhs_amount8box").hide();
				 $("#fhs_amount2box_span").live('click',function(){$("#fhs_amount2box").show();$("#delfhs_amount2box_span").show();$("#fhs_amount2box_span").hide();});
				 $("#fhs_amount3box_span").live('click',function(){$("#fhs_amount3box").show();$("#delfhs_amount3box_span").show();$("#fhs_amount3box_span").hide();});
				 $("#fhs_amount4box_span").live('click',function(){$("#fhs_amount4box").show();$("#delfhs_amount4box_span").show();$("#fhs_amount4box_span").hide();});
				 $("#fhs_amount5box_span").live('click',function(){$("#fhs_amount5box").show();$("#delfhs_amount5box_span").show();$("#fhs_amount5box_span").hide();});
				 $("#fhs_amount6box_span").live('click',function(){$("#fhs_amount6box").show();$("#delfhs_amount6box_span").show();$("#fhs_amount6box_span").hide();});
				 $("#fhs_amount7box_span").live('click',function(){$("#fhs_amount7box").show();$("#delfhs_amount7box_span").show();$("#fhs_amount7box_span").hide();});
				 $("#fhs_amount8box_span").live('click',function(){$("#fhs_amount8box").show();$("#delfhs_amount8box_span").show();$("#fhs_amount8box_span").hide();});

				 $("#delfhs_amount8box_span").live('click',function(){$("#fhs_amount8box").hide();$("#delfhs_amount8box_span").hide();$("#fhs_amount8box_span").show();});
				 $("#delfhs_amount7box_span").live('click',function(){$("#fhs_amount7box").hide();$("#delfhs_amount7box_span").hide();$("#fhs_amount7box_span").show();});
				 $("#delfhs_amount6box_span").live('click',function(){$("#fhs_amount6box").hide();$("#delfhs_amount6box_span").hide();$("#fhs_amount6box_span").show();});
				 $("#delfhs_amount5box_span").live('click',function(){$("#fhs_amount5box").hide();$("#delfhs_amount5box_span").hide();$("#fhs_amount5box_span").show();});
				 $("#delfhs_amount4box_span").live('click',function(){$("#fhs_amount4box").hide();$("#delfhs_amount4box_span").hide();$("#fhs_amount4box_span").show();});
				 $("#delfhs_amount3box_span").live('click',function(){$("#fhs_amount3box").hide();$("#delfhs_amount3box_span").hide();$("#fhs_amount3box_span").show();});
				 $("#delfhs_amount2box_span").live('click',function(){$("#fhs_amount2box").hide();$("#delfhs_amount2box_span").hide();$("#fhs_amount2box_span").show();});
			
				// var isChecked = $('#radio-3').prop('checked');
				// if(isChecked){$("#total_task_hour_box").hide();$("#total_days_recur_box").show();}
			});
</script>
											<!-----end------>
											
											<div class="span12">
                                            <div class="section last">
                                                    <div>
                                                    <input type="submit" name="submit" value="Register Now" class="uibutton loading" title="Adding" />  
                                                    </div>
                                           </div>
                                    </div>
        
                                    </div><!-- row-fluid -->
                                    </form>
                                </div><!--  end widget-content -->
                            </div><!-- widget  span12 clearfix-->

                    </div>
                 <!-----------------table------------------->

                </div> <!--// End inner -->
                <span class="tip"><a  href="https://latinamericarecruitment.com" title="" >LATAM Management Recruitment</a> </span></div>
              </div> <!--// End ID content -->

  </body>
        </html>
