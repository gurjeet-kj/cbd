<?php
include('config/config.php');
if(!isset($_SESSION['user'])){
    header("Location: signin.php");
}else{
    $user = $_SESSION['user'];	
    $bookid = $_POST["bookid"];

	$delete = "DELETE FROM cbd_ticket_booking WHERE ID = '$bookid'";
	if(mysql_query($delete)){
		 header("Location: buy_ticket.php");
	}else{
		echo "Error";
	}

}


?>